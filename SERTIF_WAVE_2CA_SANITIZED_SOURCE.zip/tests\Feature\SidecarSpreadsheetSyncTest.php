<?php

namespace Tests\Feature;

use App\Jobs\ProcessSidecarSyncJob;
use App\Models\City;
use App\Models\Faculty;
use App\Models\FormField;
use App\Models\FormSchema;
use App\Models\Institution;
use App\Models\InternshipRegistration;
use App\Models\RegistrationCustomAnswer;
use App\Models\RegistrationFormSnapshot;
use App\Models\SpreadsheetConnection;
use App\Models\SpreadsheetRowSync;
use App\Models\SpreadsheetSidecarSync;
use App\Models\StudyProgram;
use App\Models\User;
use App\Services\FormBuilderService;
use App\Services\RegistrationLifecycleService;
use App\Services\RegistrationSpreadsheetMappingService;
use App\Services\SpreadsheetSyncEngineService;
use App\Services\SpreadsheetTransport\MockSpreadsheetTransport;
use App\Services\SpreadsheetTransport\SpreadsheetTransportResponse;
use Database\Seeders\Spreadsheet2026SchemaSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Queue;
use Symfony\Component\Process\Process;
use Tests\TestCase;

class SidecarSpreadsheetSyncTest extends TestCase
{
    use RefreshDatabase;

    protected User $admin;
    protected User $pemagang;
    protected SpreadsheetConnection $regConnection;
    protected MockSpreadsheetTransport $mockTransport;
    protected RegistrationSpreadsheetMappingService $mappingService;
    protected SpreadsheetSyncEngineService $syncEngine;
    protected FormBuilderService $formBuilder;

    protected function setUp(): void
    {
        parent::setUp();

        Http::preventStrayRequests();
        Mail::fake();
        Queue::fake();

        $this->seed(Spreadsheet2026SchemaSeeder::class);

        $this->formBuilder = app(FormBuilderService::class);
        $this->formBuilder->resetGracePeriodOverride();

        $this->mockTransport = new MockSpreadsheetTransport();
        $this->mappingService = app(RegistrationSpreadsheetMappingService::class);
        $this->syncEngine = new SpreadsheetSyncEngineService(
            transport: $this->mockTransport,
            registrationMappingService: $this->mappingService
        );

        $this->regConnection = SpreadsheetConnection::firstOrCreate(
            ['connection_key' => SpreadsheetConnection::KEY_REGISTRATION],
            [
                'display_name'             => 'Spreadsheet Pendaftaran Magang',
                'spreadsheet_url'          => 'https://docs.google.com/spreadsheets/d/test-reg-sheet/edit',
                'is_enabled'               => true,
                'connection_status'        => SpreadsheetConnection::STATUS_CONNECTED,
                'apps_script_endpoint_url' => 'https://script.google.com/macros/s/test-apps-script-exec/exec',
                'spreadsheet_id'           => 'test-reg-sheet',
            ]
        );
        $this->regConnection->update([
            'spreadsheet_url'          => 'https://docs.google.com/spreadsheets/d/test-reg-sheet/edit',
            'is_enabled'               => true,
            'connection_status'        => SpreadsheetConnection::STATUS_CONNECTED,
            'apps_script_endpoint_url' => 'https://script.google.com/macros/s/test-apps-script-exec/exec',
            'spreadsheet_id'           => 'test-reg-sheet',
        ]);

        $this->admin = User::create([
            'name'      => 'Admin Sidecar',
            'email'     => 'admin_sidecar_' . uniqid() . '@example.com',
            'password'  => bcrypt('password123'),
            'role'      => 'admin',
            'is_banned' => false,
        ]);

        $this->pemagang = User::create([
            'name'      => 'Pemagang Sidecar',
            'email'     => 'pemagang_sidecar_' . uniqid() . '@example.com',
            'password'  => bcrypt('password123'),
            'role'      => 'pemagang',
            'is_banned' => false,
        ]);
    }

    protected function tearDown(): void
    {
        $this->formBuilder->resetGracePeriodOverride();
        parent::tearDown();
    }

    protected function createVerifiedAcceptedRegistration(array $overrides = []): InternshipRegistration
    {
        $city = City::firstOrCreate(['name' => 'Yogyakarta']);
        $inst = Institution::firstOrCreate(['name' => 'Universitas Indonesia', 'normalized_name' => 'universitas indonesia'], ['is_active' => true]);
        $fac  = Faculty::firstOrCreate(['name' => 'Fakultas Ilmu Komputer', 'institution_id' => $inst->id]);
        $prog = StudyProgram::firstOrCreate(['name' => 'Teknik Informatika', 'faculty_id' => $fac->id]);

        $reg = InternshipRegistration::create(array_merge([
            'user_id'                 => $this->pemagang->id,
            'fullname'                => 'Budi Sidecar',
            'student_id'              => '12345678',
            'born_date'               => '2002-05-10',
            'gender'                  => 'Laki-laki',
            'phone_number'            => '081234567890',
            'institution_id'          => $inst->id,
            'faculty_id'              => $fac->id,
            'study_program_id'        => $prog->id,
            'city_id'                 => $city->id,
            'internship_interest'     => 'Programmer (Front End / Backend)',
            'start_date'              => '2026-06-01',
            'end_date'                => '2026-08-31',
            'internship_type'         => 'WFO',
            'internship_arrangement'  => 'Mandiri',
            'current_status'          => 'Mahasiswa Aktif',
            'wfo_readiness'           => 'Siap',
            'schedule_shift_readiness'=> 'Siap',
            'has_laptop'              => true,
            'planned_duration'        => '3 Bulan',
            'internship_status'       => InternshipRegistration::STATUS_ACCEPTED,
        ], $overrides));

        if (isset($overrides['created_at'])) {
            $reg->created_at = $overrides['created_at'];
            $reg->saveQuietly();
        } else {
            $reg->created_at = Carbon::create(2026, 3, 15, 10, 0, 0);
            $reg->saveQuietly();
        }

        // Catat admin acceptance pada ActivityLog agar lolos verification gate
        \App\Services\ActivityLogger::log(
            action: 'update_status',
            description: 'Status pendaftaran diubah dari waiting ke accepted',
            subject: $reg,
            actor: $this->admin,
            metadata: ['new_status' => 'accepted']
        );

        return $reg;
    }

    /**
     * 1. Sidecar sync ditahan fail-closed jika baris utama belum pernah tersinkronisasi.
     */
    public function test_sidecar_sync_held_fail_closed_if_main_row_not_synced(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();

        // Buat custom answers & snapshot
        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 'portfolio_url',
            'field_type' => 'url',
            'label'      => 'Portfolio URL',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);

        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['portfolio_url' => 'https://example.com/port'], $published, $this->admin);

        // Queue sidecar sync
        $sidecarSync = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $this->assertNotNull($sidecarSync);
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_PENDING, $sidecarSync->sync_status);

        // Process sidecar sync: Main row belum pernah sync -> FAIL CLOSED
        $result = $this->syncEngine->processSidecarSyncRecord($sidecarSync);
        $this->assertFalse($result);

        $freshSync = $sidecarSync->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_RETRYING, $freshSync->sync_status);
        $this->assertStringContainsString('MAIN_ROW_NOT_SYNCED', $freshSync->error_message);
        $this->assertNull($freshSync->last_synced_at);
        $this->assertEquals(0, $this->mockTransport->callCount);
    }

    /**
     * 2. Sidecar sync berhasil jika baris utama telah tersinkronisasi (Main.Z = Sidecar.A).
     */
    public function test_sidecar_sync_succeeds_when_main_row_is_verified_synced(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();

        // 1. Simulasikan sinkronisasi baris utama telah selesai (Main.Z = syncId)
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->assertNotNull($mainSync);
        $this->syncEngine->processSyncRecord($mainSync);
        $this->assertEquals(SpreadsheetRowSync::STATUS_SYNCED, $mainSync->fresh()->sync_status);

        // 2. Buat custom field & snapshot
        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 'custom_github',
            'field_type' => 'url',
            'label'      => 'GitHub Profile',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);
        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['custom_github' => 'https://github.com/buditest'], $published, $this->admin);

        // 3. Queue & process sidecar sync
        $sidecarSync = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $this->assertNotNull($sidecarSync);

        $result = $this->syncEngine->processSidecarSyncRecord($sidecarSync);
        $this->assertTrue($result);

        $freshSidecar = $sidecarSync->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $freshSidecar->sync_status);
        $this->assertEquals($mainSync->external_sync_id, $freshSidecar->external_sync_id);
        $this->assertNotNull($freshSidecar->last_synced_at);
        $this->assertNotNull($freshSidecar->payload_checksum);
        $this->assertEquals(2, $freshSidecar->row_index);

        // Verifikasi remote tab pada mock
        $remoteSidecar = $this->mockTransport->getRemoteRow('2026_Custom_Fields', $freshSidecar->external_sync_id);
        $this->assertNotNull($remoteSidecar);
        $this->assertEquals($freshSidecar->external_sync_id, $remoteSidecar['SERTIF_SYNC_ID']);
        $this->assertEquals((string)$reg->id, $remoteSidecar['SERTIF_REGISTRATION_ID']);
        $this->assertEquals($published->version_code, $remoteSidecar['FORM_SCHEMA_VERSION']);
        $this->assertEquals('https://github.com/buditest', $remoteSidecar['custom_github']);

        // Aggregate sync status must be synced
        $this->assertEquals('synced', $this->syncEngine->getAggregateSyncStatus($reg));
    }

    /**
     * 3. Idempotensi sidecar sync: pemanggilan ulang dengan data yang sama adalah no-op.
     */
    public function test_sidecar_sync_is_idempotent_no_op_when_checksum_unchanged(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 'custom_bio',
            'field_type' => 'textarea',
            'label'      => 'Bio',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);
        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['custom_bio' => 'Biografi lengkap'], $published, $this->admin);

        $sidecarSync = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $this->syncEngine->processSidecarSyncRecord($sidecarSync);

        $initialCalls = $this->mockTransport->callCount;

        // Jalankan ulang tanpa force
        $secondRun = $this->syncEngine->processSidecarSyncRecord($sidecarSync);
        $this->assertTrue($secondRun);

        // Tidak ada HTTP call baru
        $this->assertEquals($initialCalls, $this->mockTransport->callCount);
    }

    /**
     * 4. Transient timeout pada sidecar sync memicu retry tanpa menduplikasi baris.
     */
    public function test_sidecar_transient_timeout_retries_with_backoff_without_duplicate(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 'custom_skill',
            'field_type' => 'text',
            'label'      => 'Skill',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);
        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['custom_skill' => 'PHP Laravel'], $published, $this->admin);

        $sidecarSync = $this->syncEngine->queueSidecarSyncForRegistration($reg);

        // Simulasikan timeout setelah remote berhasil ditulis
        $this->mockTransport->simulateTimeoutAfterRemoteSuccess = true;
        $resTimeout = $this->syncEngine->processSidecarSyncRecord($sidecarSync);
        $this->assertFalse($resTimeout);

        $freshSync = $sidecarSync->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_RETRYING, $freshSync->sync_status);
        $this->assertEquals(1, $freshSync->attempt_count);
        $this->assertNotNull($freshSync->next_retry_at);

        // Retry kedua saat koneksi kembali normal
        $this->mockTransport->simulateTimeoutAfterRemoteSuccess = false;
        $resRetry = $this->syncEngine->processSidecarSyncRecord($freshSync);
        $this->assertTrue($resRetry);

        // Baris remote tepat 1 (tidak duplikat)
        $this->assertEquals(1, $this->mockTransport->getRemoteRowCount('2026_Custom_Fields'));
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $freshSync->fresh()->sync_status);
    }

    /**
     * 5. Partial failure tracking: Main row synced namun sidecar pending/failed menghasilkan status agregat parsial.
     */
    public function test_partial_main_and_sidecar_failure_status_distinction(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);
        $this->assertEquals(SpreadsheetRowSync::STATUS_SYNCED, $mainSync->fresh()->sync_status);

        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 'custom_notes',
            'field_type' => 'text',
            'label'      => 'Notes',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);
        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['custom_notes' => 'Catatan'], $published, $this->admin);

        $sidecarSync = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_PENDING, $sidecarSync->sync_status);

        // Sebelum sidecar disinkronkan: main sudah synced, sidecar pending -> status agregat partial_main_synced
        $this->assertEquals('partial_main_synced', $this->syncEngine->getAggregateSyncStatus($reg));

        // Jika sidecar gagal:
        $sidecarSync->update(['sync_status' => SpreadsheetSidecarSync::STATUS_FAILED]);
        $this->assertEquals('failed', $this->syncEngine->getAggregateSyncStatus($reg));
    }

    /**
     * 6. Option 1: Registrasi legacy tanpa form snapshot/custom answers membuat baris placeholder 1:1 setelah baris utama tersinkronisasi.
     */
    public function test_legacy_registration_creates_sidecar_placeholder_row(): void
    {
        // a. Registrasi unaccepted / waiting tidak boleh dibuatkan placeholder
        $unacceptedReg = $this->createVerifiedAcceptedRegistration(['internship_status' => InternshipRegistration::STATUS_WAITING]);
        $this->assertFalse($this->mappingService->requiresSidecarSync($unacceptedReg));
        $this->assertNull($this->syncEngine->queueSidecarSyncForRegistration($unacceptedReg));

        // b. Registrasi verified accepted sebelum baris utama sync belum memerlukan sidecar
        $reg = $this->createVerifiedAcceptedRegistration();
        $this->assertFalse($this->mappingService->requiresSidecarSync($reg));

        // c. Sinkronisasikan baris utama terlebih dahulu
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);
        $this->assertEquals(SpreadsheetRowSync::STATUS_SYNCED, $mainSync->fresh()->sync_status);

        // d. Setelah baris utama terverifikasi sync, sidecar placeholder WAJIB dibuat (Option 1)
        $this->assertTrue($this->mappingService->requiresSidecarSync($reg));
        $sidecarSync = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $this->assertNotNull($sidecarSync);
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_PENDING, $sidecarSync->sync_status);

        // e. Proses sinkronisasi sidecar placeholder
        $result = $this->syncEngine->processSidecarSyncRecord($sidecarSync);
        $this->assertTrue($result);

        $freshSidecar = $sidecarSync->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $freshSidecar->sync_status);
        $this->assertNull($freshSidecar->form_schema_version);
        $this->assertNotNull($freshSidecar->last_synced_at);

        // f. Verifikasi struktur remote baris placeholder:
        // A = syncId, B = regId, C = blank (''), D = last_synced_at, E+ = tidak ada kolom tambahan
        $remoteSidecar = $this->mockTransport->getRemoteRow('2026_Custom_Fields', $freshSidecar->external_sync_id);
        $this->assertNotNull($remoteSidecar);
        $this->assertEquals($freshSidecar->external_sync_id, $remoteSidecar['SERTIF_SYNC_ID']);
        $this->assertEquals((string) $reg->id, $remoteSidecar['SERTIF_REGISTRATION_ID']);
        $this->assertEquals('', $remoteSidecar['FORM_SCHEMA_VERSION']);
        $this->assertNotEmpty($remoteSidecar['SERTIF_LAST_SYNC_AT']);

        // g. Status agregat harus 'synced'
        $this->assertEquals('synced', $this->syncEngine->getAggregateSyncStatus($reg));
    }

    /**
     * 7. Gate B Compatibility: Halaman pendaftaran tidak crash saat tabel form_schemas unmigrated.
     */
    public function test_gate_b_unmigrated_form_schemas_compatibility(): void
    {
        // Akses route formulir pendaftaran oleh pemagang
        $res = $this->actingAs($this->pemagang)->get(route('pemagang.registration.form'));
        $res->assertOk();
        $res->assertSee('Form Pendaftaran Magang');
    }

    /**
     * 8. Pemicu otomatis sidecar: Setelah sinkronisasi baris utama berhasil, sidecar otomatis diantrekan dan job dipicu.
     */
    public function test_sidecar_sync_auto_triggered_after_successful_main_row_sync(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();

        // Siapkan custom field dan snapshot
        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 'portfolio_url',
            'field_type' => 'url',
            'label'      => 'Portfolio',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);
        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['portfolio_url' => 'https://example.com/port'], $published, $this->admin);

        // Sebelum main sync: sidecar sync belum ada
        $this->assertDatabaseMissing('spreadsheet_sidecar_syncs', [
            'internship_registration_id' => $reg->id,
        ]);

        // Antrekan dan proses main sync
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $result = $this->syncEngine->processSyncRecord($mainSync);
        $this->assertTrue($result);
        $this->assertEquals(SpreadsheetRowSync::STATUS_SYNCED, $mainSync->fresh()->sync_status);

        // Sidecar sync otomatis dibuat dengan status pending
        $this->assertDatabaseHas('spreadsheet_sidecar_syncs', [
            'internship_registration_id' => $reg->id,
            'sync_status'                => SpreadsheetSidecarSync::STATUS_PENDING,
        ]);

        $sidecarSync = SpreadsheetSidecarSync::where('internship_registration_id', $reg->id)->first();
        $this->assertNotNull($sidecarSync);

        // ProcessSidecarSyncJob wajib dipush ke antrean
        Queue::assertPushed(ProcessSidecarSyncJob::class, function ($job) use ($sidecarSync) {
            return $job->sidecarSyncId === $sidecarSync->id;
        });
    }

    /**
     * 9. Sidecar tidak dipicu jika sinkronisasi baris utama gagal.
     */
    public function test_sidecar_sync_not_triggered_when_main_sync_fails(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();

        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 'notes',
            'field_type' => 'text',
            'label'      => 'Notes',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);
        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['notes' => 'Catatan'], $published, $this->admin);

        // Paksa main sync gagal
        $this->mockTransport->forcedResponse = SpreadsheetTransportResponse::failure(
            'Koneksi Google Sheets terputus',
            'NETWORK_ERROR',
            true
        );

        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $result = $this->syncEngine->processSyncRecord($mainSync);
        $this->assertFalse($result);
        $this->assertEquals(SpreadsheetRowSync::STATUS_RETRYING, $mainSync->fresh()->sync_status);

        // Sidecar sync TIDAK boleh dibuat atau dipush
        $this->assertDatabaseMissing('spreadsheet_sidecar_syncs', [
            'internship_registration_id' => $reg->id,
        ]);
        Queue::assertNotPushed(ProcessSidecarSyncJob::class);
    }

    /**
     * 10. Kegagalan penambahan kolom header ekstensi (ensureExtensionColumns) menggugurkan mutasi baris sidecar (fail-closed).
     */
    public function test_ensure_extension_columns_failure_aborts_without_calling_upsert(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 'hobby',
            'field_type' => 'text',
            'label'      => 'Hobi',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);
        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['hobby' => 'Membaca'], $published, $this->admin);

        $sidecarSync = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $this->assertNotNull($sidecarSync);

        // Simulasikan kegagalan pada ensureExtensionColumns
        $this->mockTransport->forcedEnsureResponse = SpreadsheetTransportResponse::failure(
            'Header expansion lock timeout',
            'HEADER_LOCK_TIMEOUT',
            true
        );

        $initialCallCount = count($this->mockTransport->callHistory);
        $result = $this->syncEngine->processSidecarSyncRecord($sidecarSync);

        $this->assertFalse($result);

        $fresh = $sidecarSync->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_RETRYING, $fresh->sync_status);
        $this->assertStringContainsString('HEADER_LOCK_TIMEOUT', $fresh->error_message);

        // Pastikan upsertExtensionRow TIDAK PERNAH dipanggil dalam history
        $upsertCalls = array_filter(
            $this->mockTransport->callHistory,
            fn($c) => ($c['action'] ?? '') === 'upsert_extension_row'
        );
        $this->assertEmpty($upsertCalls, 'upsertExtensionRow must NOT be called when ensureExtensionColumns fails!');
    }

    /**
     * 11. Remote identity incomplete: Baris utama dengan cell SERTIF_REGISTRATION_ID kosong menolak mutasi sidecar.
     */
    public function test_remote_identity_incomplete_rejects_upsert(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 'skill',
            'field_type' => 'text',
            'label'      => 'Skill',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);
        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['skill' => 'PHP'], $published, $this->admin);

        $sidecarSync = $this->syncEngine->queueSidecarSyncForRegistration($reg);

        // Ubah baris utama remote agar cell registration id kosong
        $syncId = $sidecarSync->external_sync_id;
        $this->mockTransport->remoteSheets['2026'][$syncId]['SERTIF_REGISTRATION_ID'] = '';
        $this->mockTransport->remoteSheets['2026'][$syncId]['sertif_registration_id'] = '';

        $result = $this->syncEngine->processSidecarSyncRecord($sidecarSync);
        $this->assertFalse($result);

        $fresh = $sidecarSync->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_FAILED, $fresh->sync_status);
        $this->assertStringContainsString('REMOTE_IDENTITY_INCOMPLETE', $fresh->error_message);
    }

    /**
     * 12. Rekonsiliasi manual terarah: reconcileSidecarForRegistration hanya memproses registrasi diterima dengan prior main sync.
     */
    public function test_controlled_reconciliation_sidecar_for_registration(): void
    {
        // a. Registrasi unaccepted: ditolak (return null)
        $unaccepted = $this->createVerifiedAcceptedRegistration(['internship_status' => InternshipRegistration::STATUS_PENDING]);
        $resUnaccepted = $this->syncEngine->reconcileSidecarForRegistration($unaccepted, $this->admin);
        $this->assertNull($resUnaccepted);

        // b. Registrasi accepted tetapi belum pernah main sync: ditolak (return null)
        $unSyncedReg = $this->createVerifiedAcceptedRegistration();
        $resUnsynced = $this->syncEngine->reconcileSidecarForRegistration($unSyncedReg, $this->admin);
        $this->assertNull($resUnsynced);

        // c. Registrasi accepted dengan prior main sync: berhasil direkonsiliasi
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $reconciled = $this->syncEngine->reconcileSidecarForRegistration($reg, $this->admin);
        $this->assertNotNull($reconciled);
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_PENDING, $reconciled->sync_status);
        $this->assertEquals(0, $reconciled->attempt_count);
        $this->assertNull($reconciled->payload_checksum);

        Queue::assertPushed(ProcessSidecarSyncJob::class, function ($job) use ($reconciled) {
            return $job->sidecarSyncId === $reconciled->id;
        });

        // Verifikasi audit log
        $this->assertDatabaseHas('activity_logs', [
            'action'        => 'spreadsheet_sidecar_reconcile_triggered',
            'actor_user_id' => $this->admin->id,
            'subject_id'    => $reg->id,
        ]);
    }

    /**
     * 13. Scanner pemulihan background: scanAndDispatchPendingSidecarSyncs mengambil record due pending/retrying.
     */
    public function test_scan_and_dispatch_pending_sidecar_syncs(): void
    {
        $reg1 = $this->createVerifiedAcceptedRegistration();
        $mainSync1 = $this->syncEngine->queueSyncForRegistration($reg1);
        $this->syncEngine->processSyncRecord($mainSync1);

        $sidecar1 = $this->syncEngine->queueSidecarSyncForRegistration($reg1);
        $sidecar1->update([
            'sync_status'   => SpreadsheetSidecarSync::STATUS_PENDING,
            'next_retry_at' => now()->subMinute(),
            'locked_at'     => null,
        ]);

        $reg2 = $this->createVerifiedAcceptedRegistration(['fullname' => 'Siti Sidecar']);
        $mainSync2 = $this->syncEngine->queueSyncForRegistration($reg2);
        $this->syncEngine->processSyncRecord($mainSync2);

        $sidecar2 = $this->syncEngine->queueSidecarSyncForRegistration($reg2);
        $sidecar2->update([
            'sync_status'   => SpreadsheetSidecarSync::STATUS_RETRYING,
            'next_retry_at' => now()->subMinutes(2),
            'locked_at'     => null,
        ]);

        // Rekord yang belum waktunya (future next_retry_at) tidak boleh didispatch
        $reg3 = $this->createVerifiedAcceptedRegistration(['fullname' => 'Future Sidecar']);
        $mainSync3 = $this->syncEngine->queueSyncForRegistration($reg3);
        $this->syncEngine->processSyncRecord($mainSync3);

        $sidecar3 = $this->syncEngine->queueSidecarSyncForRegistration($reg3);
        $sidecar3->update([
            'sync_status'   => SpreadsheetSidecarSync::STATUS_RETRYING,
            'next_retry_at' => now()->addHour(),
            'locked_at'     => null,
        ]);

        $dispatchedCount = $this->syncEngine->scanAndDispatchPendingSidecarSyncs(limit: 50);

        $this->assertEquals(2, $dispatchedCount);
        Queue::assertPushed(ProcessSidecarSyncJob::class, function ($job) use ($sidecar1) {
            return $job->sidecarSyncId === $sidecar1->id;
        });
        Queue::assertPushed(ProcessSidecarSyncJob::class, function ($job) use ($sidecar2) {
            return $job->sidecarSyncId === $sidecar2->id;
        });
    }

    /**
     * 14. Active processing lease cannot be stolen by another worker.
     */
    public function test_active_processing_lease_cannot_be_stolen(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $sidecar = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $activeToken = 'worker-active-' . uniqid();

        // Worker A aktif memproses dengan locked_at sekarang (lease aktif)
        $sidecar->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now(),
            'locked_by'   => $activeToken,
        ]);

        // Worker B mencoba mengklaim baris yang sedang aktif
        $claimedByB = $this->syncEngine->processSidecarSyncRecord($sidecar);
        $this->assertFalse($claimedByB, 'Worker B must NOT steal active lease!');

        // locked_by tetap milik Worker A
        $this->assertEquals($activeToken, $sidecar->fresh()->locked_by);
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_PROCESSING, $sidecar->fresh()->sync_status);
    }

    /**
     * 15. Expired processing lease can be reclaimed safely.
     */
    public function test_expired_processing_lease_can_be_reclaimed(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $sidecar = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $staleToken = 'worker-dead-' . uniqid();

        // Worker lama mati dan meninggalkan locked_at kedaluwarsa (> 300 detik yang lalu)
        $sidecar->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now()->subSeconds(360),
            'locked_by'   => $staleToken,
        ]);

        // Worker baru harus berhasil mengklaim lease dan memproses hingga selesai
        $reclaimed = $this->syncEngine->processSidecarSyncRecord($sidecar);
        $this->assertTrue($reclaimed, 'Expired lease MUST be reclaimed!');

        $fresh = $sidecar->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $fresh->sync_status);
        $this->assertNull($fresh->locked_by);
        $this->assertNull($fresh->locked_at);
    }

    /**
     * 16. Two workers racing to reclaim expired lease: only one owner succeeds.
     */
    public function test_two_workers_racing_to_reclaim_only_allow_one_owner(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $sidecar = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecar->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now()->subMinutes(10),
            'locked_by'   => 'dead-worker',
        ]);

        $tokenA = 'token-worker-A';
        $tokenB = 'token-worker-B';

        // Worker A mengklaim dengan fencing token A
        $claimedA = DB::table('spreadsheet_sidecar_syncs')
            ->where('id', $sidecar->id)
            ->where(function ($query) {
                $query->where(function ($q) {
                    $q->where('sync_status', '!=', SpreadsheetSidecarSync::STATUS_PROCESSING)
                      ->where(function ($lq) {
                          $lq->whereNull('locked_at')
                             ->orWhere('locked_at', '<', now()->subSeconds(300));
                      });
                })
                ->orWhere(function ($q) {
                    $q->where('sync_status', SpreadsheetSidecarSync::STATUS_PROCESSING)
                      ->whereNotNull('locked_at')
                      ->where('locked_at', '<', now()->subSeconds(300));
                });
            })
            ->update([
                'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
                'locked_at'   => now(),
                'locked_by'   => $tokenA,
                'updated_at'  => now(),
            ]);

        // Worker B mencoba mengklaim tepat setelahnya
        $claimedB = DB::table('spreadsheet_sidecar_syncs')
            ->where('id', $sidecar->id)
            ->where(function ($query) {
                $query->where(function ($q) {
                    $q->where('sync_status', '!=', SpreadsheetSidecarSync::STATUS_PROCESSING)
                      ->where(function ($lq) {
                          $lq->whereNull('locked_at')
                             ->orWhere('locked_at', '<', now()->subSeconds(300));
                      });
                })
                ->orWhere(function ($q) {
                    $q->where('sync_status', SpreadsheetSidecarSync::STATUS_PROCESSING)
                      ->whereNotNull('locked_at')
                      ->where('locked_at', '<', now()->subSeconds(300));
                });
            })
            ->update([
                'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
                'locked_at'   => now(),
                'locked_by'   => $tokenB,
                'updated_at'  => now(),
            ]);

        $this->assertEquals(1, $claimedA, 'Worker A must win the race');
        $this->assertEquals(0, $claimedB, 'Worker B must fail to claim');
        $this->assertEquals($tokenA, $sidecar->fresh()->locked_by);
    }

    /**
     * 17. Previous owner cannot finalize after lease takeover.
     */
    public function test_previous_owner_cannot_finalize_after_lease_takeover(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $sidecar = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $staleToken = 'token-worker-old';
        $newToken = 'token-worker-new';

        // Worker baru telah mengambil alih lease
        $sidecar->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now(),
            'locked_by'   => $newToken,
        ]);

        // Worker lama mencoba melakukan update berpagar token lama
        $reflection = new \ReflectionClass($this->syncEngine);
        $updateFenceMethod = $reflection->getMethod('updateSidecarGuardedByFence');
        $updateFenceMethod->setAccessible(true);

        $success = $updateFenceMethod->invoke(
            $this->syncEngine,
            $sidecar,
            $staleToken,
            ['sync_status' => SpreadsheetSidecarSync::STATUS_SYNCED]
        );

        $this->assertFalse($success, 'Old worker write MUST be rejected by fencing token mismatch!');
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_PROCESSING, $sidecar->fresh()->sync_status);
        $this->assertEquals($newToken, $sidecar->fresh()->locked_by);
    }

    /**
     * 18. Remote write succeeded but local update failed: retry does not create duplicate.
     */
    public function test_remote_write_succeeded_but_local_update_failed_retry_does_not_create_duplicate(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $sidecar = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $syncId = $sidecar->external_sync_id;

        // Simulasikan baris sudah tertulis di remote Google Sheets
        $this->mockTransport->remoteSheets['2026_Custom_Fields'][$syncId] = [
            'SERTIF_SYNC_ID'         => $syncId,
            'SERTIF_REGISTRATION_ID' => (string) $reg->id,
            'FORM_SCHEMA_VERSION'    => '',
            'SERTIF_LAST_SYNC_AT'    => now()->toIso8601String(),
        ];

        $initialRowCount = $this->mockTransport->getRemoteRowCount('2026_Custom_Fields');
        $this->assertEquals(1, $initialRowCount);

        // Eksekusi retry
        $res = $this->syncEngine->processSidecarSyncRecord($sidecar);
        $this->assertTrue($res);

        // Baris remote tetap tepat 1 (update in-place, tidak membuat duplikat)
        $this->assertEquals(1, $this->mockTransport->getRemoteRowCount('2026_Custom_Fields'));
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $sidecar->fresh()->sync_status);
    }

    /**
     * 19. Lease recovery does not bypass verified acceptance or main sync prerequisites.
     */
    public function test_lease_recovery_does_not_bypass_verified_acceptance_or_main_sync_prerequisites(): void
    {
        // a. Registrasi berstatus waiting (belum accepted) dengan lease expired
        $unacceptedReg = $this->createVerifiedAcceptedRegistration(['internship_status' => InternshipRegistration::STATUS_WAITING]);
        $sidecar = SpreadsheetSidecarSync::create([
            'spreadsheet_connection_id'  => $this->regConnection->id,
            'internship_registration_id' => $unacceptedReg->id,
            'external_sync_id'           => 'REG-UNACCEPTED-' . uniqid(),
            'main_sheet_tab'             => '2026',
            'extension_sheet_tab'        => '2026_Custom_Fields',
            'sync_status'                => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'                  => now()->subMinutes(10),
            'locked_by'                  => 'stale-worker',
        ]);

        $res = $this->syncEngine->processSidecarSyncRecord($sidecar);
        $this->assertFalse($res);
        $this->assertStringContainsString('MAIN_ROW_NOT_SYNCED', $sidecar->fresh()->error_message);

        // b. Rekonsiliasi manual juga menolak registrasi yang belum accepted
        $resReconcile = $this->syncEngine->reconcileSidecarForRegistration($unacceptedReg, $this->admin);
        $this->assertNull($resReconcile);
    }

    /**
     * 20. Year-based sidecar mapping: 2026 -> 2026_Custom_Fields, 2027 -> 2027_Custom_Fields, invalid -> fail-closed.
     */
    public function test_year_based_sidecar_mapping_2026_and_2027_and_invalid_fail_closed(): void
    {
        // 1. Tahun 2026
        $reg2026 = $this->createVerifiedAcceptedRegistration(['created_at' => \Illuminate\Support\Carbon::create(2026, 4, 1, 10, 0, 0)]);
        $mainSync2026 = $this->syncEngine->queueSyncForRegistration($reg2026);
        $this->syncEngine->processSyncRecord($mainSync2026);

        $sidecar2026 = $this->syncEngine->queueSidecarSyncForRegistration($reg2026);
        $this->assertNotNull($sidecar2026);
        $this->assertEquals('2026', $sidecar2026->main_sheet_tab);
        $this->assertEquals('2026_Custom_Fields', $sidecar2026->extension_sheet_tab);

        // 2. Tahun 2027
        // Siapkan schema version 2027
        $schema2026 = \App\Models\SpreadsheetSchemaVersion::where('year', 2026)->first();
        $schema2027 = \App\Models\SpreadsheetSchemaVersion::create([
            'spreadsheet_connection_id' => $this->regConnection->id,
            'year'                      => 2027,
            'schema_version'            => 'v1',
            'sheet_tab_name'            => '2027',
            'is_active'                 => true,
            'notes'                     => '2027 Schema Contract',
        ]);
        foreach ($schema2026->columnMappings as $mapping) {
            $m = $mapping->replicate();
            $m->spreadsheet_schema_version_id = $schema2027->id;
            $m->public_uuid = (string) \Illuminate\Support\Str::uuid();
            $m->save();
        }

        $reg2027 = $this->createVerifiedAcceptedRegistration(['created_at' => \Illuminate\Support\Carbon::create(2027, 2, 10, 9, 0, 0)]);
        $mainSync2027 = $this->syncEngine->queueSyncForRegistration($reg2027);
        $this->syncEngine->processSyncRecord($mainSync2027);

        $sidecar2027 = $this->syncEngine->queueSidecarSyncForRegistration($reg2027);
        $this->assertNotNull($sidecar2027);
        $this->assertEquals('2027', $sidecar2027->main_sheet_tab);
        $this->assertEquals('2027_Custom_Fields', $sidecar2027->extension_sheet_tab);

        // Verifikasi main sheet tetap 29 kolom
        $outboundPayload = $this->mappingService->buildOutboundRowPayload($reg2027);
        $this->assertCount(29, $outboundPayload);

        // 3. Tanggal null atau tidak valid -> fail-closed (returns null)
        $invalidReg = $this->createVerifiedAcceptedRegistration(['created_at' => null]);
        $invalidReg->created_at = null;
        $invalidReg->saveQuietly();

        $sidecarInvalid = $this->syncEngine->queueSidecarSyncForRegistration($invalidReg);
        $this->assertNull($sidecarInvalid, 'Invalid/null created_at MUST fail-closed!');
    }

    /**
     * 21. SpreadsheetSyncRecoveryCommand supports --dry-run and --include-sidecar options safely.
     */
    public function test_spreadsheet_sync_recovery_command_with_dry_run_and_include_sidecar(): void
    {
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->syncEngine->processSyncRecord($mainSync);

        $sidecar = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecar->update([
            'sync_status'   => SpreadsheetSidecarSync::STATUS_PENDING,
            'next_retry_at' => now()->subMinute(),
            'locked_at'     => null,
        ]);

        // A. Mode --dry-run: simulasi tidak mendispatch job
        Queue::fake();

        $this->artisan('sertif:spreadsheet-sync:recover', [
            '--dry-run'         => true,
            '--include-sidecar' => true,
        ])
        ->expectsOutputToContain('[DRY-RUN]')
        ->assertExitCode(0);

        // Tidak boleh ada job yang didispatch saat dry-run
        Queue::assertNothingPushed();

        // B. Mode aktif dengan --include-sidecar: mendispatch job
        $this->artisan('sertif:spreadsheet-sync:recover', [
            '--include-sidecar' => true,
        ])
        ->assertExitCode(0);

        Queue::assertPushed(ProcessSidecarSyncJob::class, function ($job) use ($sidecar) {
            return $job->sidecarSyncId === $sidecar->id;
        });
    }

    /**
     * 22. R02 Fix 1, 2, 3: Invalid signature does not consume nonce, and replay protection is concurrency-safe.
     */
    public function test_r02_invalid_signature_does_not_consume_nonce_and_replay_protection_is_concurrency_safe(): void
    {
        $nodeScript = <<<'JS'
const crypto = require("crypto");
const path = require("path");
const appsScript = require(path.resolve("./resources/apps-script/SertifGoogleIntegration.js"));

const SECRET = "test_shared_secret_r02_key_987654321";

const cacheStore = {};
global.CacheService = {
  getScriptCache: () => ({
    get: (k) => cacheStore[k] || null,
    put: (k, v, ttl) => { cacheStore[k] = v; }
  })
};

global.PropertiesService = {
  getScriptProperties: () => ({
    getProperty: (k) => (k === "SHARED_API_KEY" ? SECRET : null)
  })
};

let lockAcquiredCount = 0;
let lockReleasedCount = 0;
global.LockService = {
  getScriptLock: () => ({
    tryLock: () => { lockAcquiredCount++; return true; },
    waitLock: () => { lockAcquiredCount++; return true; },
    hasLock: () => true,
    releaseLock: () => { lockReleasedCount++; }
  })
};

global.Utilities = {
  Charset: { UTF_8: "UTF_8" },
  computeHmacSha256Signature: (data, key) => {
    const hmac = crypto.createHmac("sha256", key);
    hmac.update(data, "utf8");
    const digest = hmac.digest();
    return Array.from(digest).map(b => (b > 127 ? b - 256 : b));
  }
};

function signRequest(timestamp, nonce, payload, secret) {
  const canonicalData = timestamp + "." + nonce + "." + JSON.stringify(payload);
  const hmac = crypto.createHmac("sha256", secret);
  hmac.update(canonicalData, "utf8");
  return hmac.digest("hex");
}

const currentTs = Math.floor(Date.now() / 1000);
const nonceTest = "test-nonce-r02-unique";
const testPayload = { action: "ping", test: 123 };

// Step 1: Corrupted signature -> rejected, nonce NOT stored in cache
const badSigRes = appsScript.validateAuthentication({
  timestamp: currentTs,
  nonce: nonceTest,
  signature: "invalid_corrupted_signature_hex",
  payload: testPayload
});
const step1_ok = badSigRes && badSigRes.error_code === "INVALID_SIGNATURE";
const step1_nonce_not_consumed = (cacheStore["nonce_" + nonceTest] === undefined);

// Step 2: Valid signature with SAME nonce must succeed (proving nonce was NOT consumed by bad request)
const validSig = signRequest(currentTs, nonceTest, testPayload, SECRET);
const validRes = appsScript.validateAuthentication({
  timestamp: currentTs,
  nonce: nonceTest,
  signature: validSig,
  payload: testPayload
});
const step2_ok = (validRes === null);
const step2_nonce_consumed = (cacheStore["nonce_" + nonceTest] === "1");

// Step 3: Replaying the valid request with the SAME nonce must be rejected
const replayRes = appsScript.validateAuthentication({
  timestamp: currentTs,
  nonce: nonceTest,
  signature: validSig,
  payload: testPayload
});
const step3_ok = replayRes && replayRes.error_code === "REPLAYED_NONCE";

// Step 4: Concurrency lock was used
const step4_lock_ok = lockAcquiredCount > 0 && lockReleasedCount === lockAcquiredCount;

process.stdout.write(JSON.stringify({
  step1_ok,
  step1_nonce_not_consumed,
  step2_ok,
  step2_nonce_consumed,
  step3_ok,
  step4_lock_ok
}));
JS;

        $process = new Process(['node', '-e', $nodeScript]);
        $process->mustRun();
        $output = json_decode(trim($process->getOutput()), true, 512, JSON_THROW_ON_ERROR);

        $this->assertTrue($output['step1_ok'], 'Invalid signature request MUST return INVALID_SIGNATURE.');
        $this->assertTrue($output['step1_nonce_not_consumed'], 'Invalid signature request MUST NOT consume or cache nonce.');
        $this->assertTrue($output['step2_ok'], 'Subsequent valid signature with same nonce MUST succeed.');
        $this->assertTrue($output['step2_nonce_consumed'], 'Authenticated request MUST cache nonce.');
        $this->assertTrue($output['step3_ok'], 'Replayed request with identical nonce MUST return REPLAYED_NONCE.');
        $this->assertTrue($output['step4_lock_ok'], 'LockService MUST be acquired and released during nonce verification.');
    }

    /**
     * 23. R02 Fix 4: Duplicate and identity mismatch checks on sidecar MUST execute before header modification.
     */
    public function test_r02_sidecar_duplicate_and_identity_mismatch_prevent_header_modification(): void
    {
        $nodeScript = <<<'JS'
const crypto = require("crypto");
const path = require("path");
const appsScript = require(path.resolve("./resources/apps-script/SertifGoogleIntegration.js"));

const SECRET = "test_shared_secret_r02_sidecar_key";
const REG_ID = "test-spreadsheet-id";

global.PropertiesService = {
  getScriptProperties: () => ({
    getProperty: (k) => {
      if (k === "SHARED_API_KEY") return SECRET;
      if (k === "REGISTRATION_SPREADSHEET_ID") return REG_ID;
      return null;
    }
  })
};

global.LockService = {
  getScriptLock: () => ({
    tryLock: () => true,
    waitLock: () => true,
    hasLock: () => true,
    releaseLock: () => {}
  })
};

global.Utilities = {
  Charset: { UTF_8: "UTF_8" },
  computeHmacSha256Signature: (data, key) => {
    const hmac = crypto.createHmac("sha256", key);
    hmac.update(data, "utf8");
    const digest = hmac.digest();
    return Array.from(digest).map(b => (b > 127 ? b - 256 : b));
  }
};

let headersModified = false;
let rowValuesWritten = false;
let currentScenario = "dup";

global.SpreadsheetApp = {
  openById: () => ({
    getSheetByName: (tab) => {
      if (tab === "2026") {
        return {
          getLastRow: () => 2,
          getLastColumn: () => 27,
          getRange: (r, c, numR, numC) => {
            if (r === 1 && numR === 1) {
              const headers = [];
              for (let i = 1; i <= 25; i++) headers.push("COL_" + i);
              headers.push("SERTIF_SYNC_ID");
              headers.push("SERTIF_REGISTRATION_ID");
              return { getValues: () => [headers] };
            }
            if (r === 2 && c === 26) return { getValues: () => [["REG-SYNC-1"]], getValue: () => "REG-SYNC-1" };
            if (r === 2 && c === 27) return { getValue: () => "101" };
            return { getValues: () => [[]], getValue: () => "" };
          }
        };
      }
      if (tab === "2026_Custom_Fields") {
        return {
          getLastRow: () => (currentScenario === "dup" ? 3 : 2),
          getLastColumn: () => 4,
          getRange: (r, c, numR, numC) => {
            return {
              getValues: () => {
                if (r === 1) return [["SERTIF_SYNC_ID", "SERTIF_REGISTRATION_ID", "FORM_SCHEMA_VERSION", "SERTIF_LAST_SYNC_AT"]];
                if (r === 2 && c === 1) {
                  if (currentScenario === "dup") return [["REG-SYNC-1"], ["REG-SYNC-1"]];
                  return [["REG-SYNC-1"]];
                }
                return [[]];
              },
              getValue: () => {
                if (r >= 2 && c === 1) return "REG-SYNC-1";
                if (r >= 2 && c === 2) {
                  if (currentScenario === "mismatch") return "999";
                  return "101";
                }
                return "";
              },
              setValue: () => { headersModified = true; },
              setValues: () => { rowValuesWritten = true; }
            };
          }
        };
      }
      return null;
    }
  }),
  flush: () => {}
};

// Scenario A: Duplicate sidecar rows exist (>1 match)
currentScenario = "dup";
headersModified = false;
rowValuesWritten = false;
const resA = appsScript.handleUpsertExtensionRowAction({
  action: "upsert_extension_row",
  main_sheet_name: "2026",
  extension_sheet_name: "2026_Custom_Fields",
  sync_id: "REG-SYNC-1",
  registration_id: "101",
  form_schema_version: "2026.v1",
  answers: { "unseen_header_col_a": "val_a" }
});
const a_rejected = resA.statusCode === 422 && resA.data.error_code === "DUPLICATE_SIDECAR_SYNC_ID";
const a_headers_intact = !headersModified;
const a_rows_intact = !rowValuesWritten;

// Scenario B: Identity mismatch on existing sidecar row (remote 999 vs payload 101)
currentScenario = "mismatch";
headersModified = false;
rowValuesWritten = false;
const resB = appsScript.handleUpsertExtensionRowAction({
  action: "upsert_extension_row",
  main_sheet_name: "2026",
  extension_sheet_name: "2026_Custom_Fields",
  sync_id: "REG-SYNC-1",
  registration_id: "101",
  form_schema_version: "2026.v1",
  answers: { "unseen_header_col_b": "val_b" }
});
const b_rejected = resB.statusCode === 422 && resB.data.error_code === "IDENTITY_MISMATCH";
const b_headers_intact = !headersModified;
const b_rows_intact = !rowValuesWritten;

// Scenario C: Valid request with matching identity -> expands headers & updates row
currentScenario = "valid";
headersModified = false;
rowValuesWritten = false;
const resC = appsScript.handleUpsertExtensionRowAction({
  action: "upsert_extension_row",
  main_sheet_name: "2026",
  extension_sheet_name: "2026_Custom_Fields",
  sync_id: "REG-SYNC-1",
  registration_id: "101",
  form_schema_version: "2026.v1",
  answers: { "unseen_header_col_c": "val_c" }
});
const c_success = resC.statusCode === 200 && resC.data.success === true;
const c_headers_expanded = headersModified;
const c_row_written = rowValuesWritten;

process.stdout.write(JSON.stringify({
  a_rejected,
  a_headers_intact,
  a_rows_intact,
  b_rejected,
  b_headers_intact,
  b_rows_intact,
  c_success,
  c_headers_expanded,
  c_row_written
}));
JS;

        $process = new Process(['node', '-e', $nodeScript]);
        $process->mustRun();
        $output = json_decode(trim($process->getOutput()), true, 512, JSON_THROW_ON_ERROR);

        $this->assertTrue($output['a_rejected'], 'Duplicate sidecar sync ID MUST be rejected with 422 DUPLICATE_SIDECAR_SYNC_ID.');
        $this->assertTrue($output['a_headers_intact'], 'Duplicate rejection MUST NOT modify sidecar headers.');
        $this->assertTrue($output['a_rows_intact'], 'Duplicate rejection MUST NOT write any sidecar row values.');

        $this->assertTrue($output['b_rejected'], 'Sidecar identity mismatch MUST be rejected with 422 IDENTITY_MISMATCH.');
        $this->assertTrue($output['b_headers_intact'], 'Identity mismatch rejection MUST NOT modify sidecar headers.');
        $this->assertTrue($output['b_rows_intact'], 'Identity mismatch rejection MUST NOT write any sidecar row values.');

        $this->assertTrue($output['c_success'], 'Pre-requisite verified request MUST succeed with 200.');
        $this->assertTrue($output['c_headers_expanded'], 'Verified request MUST expand new headers.');
        $this->assertTrue($output['c_row_written'], 'Verified request MUST write row values.');
    }

    /**
     * S17.18G.6-A-R04: Full Lock Safety, Nonce Replay, and Time Window Matrix (T01 - T20).
     *
     * Models deterministic clock progression and TTL-based cache expiry.
     * Evaluates sequential replays, concurrency lock contention, future/past timestamp boundaries,
     * cache crashes, and replay protection across the aligned 900s retention window.
     */
    public function test_r04_full_lock_safety_nonce_replay_and_time_window_matrix_t01_to_t20(): void
    {
        $secret = 'test_shared_secret_r04_key_1122334455';
        $currentTs = 1000000;
        $canonicalData = $currentTs . '.nonce-t10.{"action":"ping","test":999}';
        $t10PhpSig = hash_hmac('sha256', $canonicalData, $secret);

        $nodeScript = <<<JS
const crypto = require('crypto');
const path = require('path');

let currentTime = 1000000; // deterministic epoch in seconds

const RealDate = Date;
global.Date = class extends RealDate {
  constructor(...args) {
    if (args.length) {
      super(...args);
    } else {
      super(currentTime * 1000);
    }
  }
  static now() {
    return currentTime * 1000;
  }
  getTime() {
    return currentTime * 1000;
  }
};

let cacheStore = {}; // key -> { value, expiresAt }
global.CacheService = {
  getScriptCache: () => ({
    get: (k) => {
      const entry = cacheStore[k];
      if (!entry) return null;
      if (currentTime >= entry.expiresAt) {
        delete cacheStore[k];
        return null;
      }
      return entry.value;
    },
    put: (k, v, ttl) => {
      cacheStore[k] = {
        value: v,
        expiresAt: currentTime + ttl
      };
    }
  })
};

const SECRET = '{$secret}';
global.PropertiesService = {
  getScriptProperties: () => ({
    getProperty: (k) => (k === 'SHARED_API_KEY' ? SECRET : null)
  })
};

let lockShouldSucceed = true;
let lockShouldThrow = false;
let lockCallCount = 0;
let lockReleaseCount = 0;

global.LockService = {
  getScriptLock: () => ({
    tryLock: (timeout) => {
      lockCallCount++;
      if (lockShouldThrow) throw new Error('Mocked Lock Error');
      return lockShouldSucceed;
    },
    waitLock: (timeout) => {
      lockCallCount++;
      if (lockShouldThrow) throw new Error('Mocked Lock Error');
      return lockShouldSucceed;
    },
    hasLock: () => lockShouldSucceed,
    releaseLock: () => { lockReleaseCount++; }
  })
};

global.Utilities = {
  Charset: { UTF_8: 'UTF_8' },
  computeHmacSha256Signature: (data, key) => {
    const hmac = crypto.createHmac('sha256', key);
    hmac.update(data, 'utf8');
    const digest = hmac.digest();
    return Array.from(digest).map(b => (b > 127 ? b - 256 : b));
  }
};

const appsScript = require(path.resolve('./resources/apps-script/SertifGoogleIntegration.js'));

function signRequest(timestamp, nonce, payload, secret) {
  const canonicalData = timestamp + '.' + nonce + '.' + JSON.stringify(payload);
  const hmac = crypto.createHmac('sha256', secret);
  hmac.update(canonicalData, 'utf8');
  return hmac.digest('hex');
}

const testPayload = { action: 'ping', test: 999 };

// --- T01 to T10 (Lock Safety & Baseline Interoperability Matrix) ---
// T01: Invalid signature rejected & nonce untouched
currentTime = 1000000;
cacheStore = {};
const t01_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t01', signature: 'invalid_sig', payload: testPayload });
const t01_ok = t01_res && t01_res.error_code === 'INVALID_SIGNATURE' && cacheStore['nonce_nonce-t01'] === undefined;

// T02: Valid signature authenticated & nonce consumed
cacheStore = {};
lockShouldSucceed = true; lockShouldThrow = false;
const t02_sig = signRequest(currentTime, 'nonce-t02', testPayload, SECRET);
const t02_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t02', signature: t02_sig, payload: testPayload });
const t02_ok = t02_res === null && cacheStore['nonce_nonce-t02'] !== undefined && cacheStore['nonce_nonce-t02'].value === '1';

// T03: Sequential replay of valid request rejected
const t03_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t02', signature: t02_sig, payload: testPayload });
const t03_ok = t03_res && t03_res.error_code === 'REPLAYED_NONCE';

// T04: Lock timeout fail-closed
cacheStore = {};
lockShouldSucceed = false; lockShouldThrow = false;
const t04_sig = signRequest(currentTime, 'nonce-t04', testPayload, SECRET);
const t04_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t04', signature: t04_sig, payload: testPayload });
const t04_ok = t04_res && t04_res.error_code === 'LOCK_TIMEOUT' && t04_res.is_retryable === true && cacheStore['nonce_nonce-t04'] === undefined;

// T05: Lock exception fail-closed
cacheStore = {};
lockShouldSucceed = true; lockShouldThrow = true;
const t05_sig = signRequest(currentTime, 'nonce-t05', testPayload, SECRET);
const t05_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t05', signature: t05_sig, payload: testPayload });
const t05_ok = t05_res && t05_res.error_code === 'LOCK_TIMEOUT' && t05_res.is_retryable === true && cacheStore['nonce_nonce-t05'] === undefined;

// T06: LockService unavailable fail-closed
const origLock = global.LockService;
global.LockService = null;
const t06_sig = signRequest(currentTime, 'nonce-t06', testPayload, SECRET);
const t06_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t06', signature: t06_sig, payload: testPayload });
const t06_ok = t06_res && t06_res.error_code === 'LOCK_SERVICE_UNAVAILABLE' && t06_res.is_retryable === true;
global.LockService = origLock;

// T07: Cache crash releases lock
const origCache = global.CacheService;
lockShouldSucceed = true; lockShouldThrow = false; lockCallCount = 0; lockReleaseCount = 0;
global.CacheService = { getScriptCache: () => { throw new Error('Cache crash'); } };
const t07_sig = signRequest(currentTime, 'nonce-t07', testPayload, SECRET);
const t07_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t07', signature: t07_sig, payload: testPayload });
const t07_ok = t07_res && t07_res.error_code === 'CACHE_SERVICE_UNAVAILABLE' && lockReleaseCount > 0 && lockReleaseCount === lockCallCount;
global.CacheService = origCache;

// T08: Nonce usable after previous lock failure
lockShouldSucceed = true; lockShouldThrow = false;
const t08_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t04', signature: t04_sig, payload: testPayload });
const t08_ok = t08_res === null && cacheStore['nonce_nonce-t04'] !== undefined;

// T09: Concurrency safety simulation (Worker 1 holds lock -> Worker 2 gets LOCK_TIMEOUT; Worker 1 commits; Worker 2 retries and gets REPLAYED_NONCE)
cacheStore = {};
const t09_sig = signRequest(currentTime, 'nonce-t09-concurrent', testPayload, SECRET);
lockShouldSucceed = true; lockShouldThrow = false;
const w1_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t09-concurrent', signature: t09_sig, payload: testPayload });
lockShouldSucceed = false;
const w2_contention_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t09-concurrent', signature: t09_sig, payload: testPayload });
lockShouldSucceed = true;
const w2_retry_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t09-concurrent', signature: t09_sig, payload: testPayload });
const t09_ok = w1_res === null && w2_contention_res.error_code === 'LOCK_TIMEOUT' && w2_retry_res.error_code === 'REPLAYED_NONCE';

// T10: PHP hash_hmac interoperability
lockShouldSucceed = true; lockShouldThrow = false;
const t10_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t10', signature: '{$t10PhpSig}', payload: testPayload });
const t10_ok = t10_res === null && cacheStore['nonce_nonce-t10'] !== undefined;

// --- T11 to T20 (R04 Replay Window & Time Alignment Matrix) ---
// T11: Timestamp masa depan +300 detik pada penerimaan pertama -> Request valid dapat diterima
currentTime = 1000000;
const t11_ts = currentTime + 300;
const t11_sig = signRequest(t11_ts, 'nonce-t11', testPayload, SECRET);
const t11_res = appsScript.validateAuthentication({ timestamp: t11_ts, nonce: 'nonce-t11', signature: t11_sig, payload: testPayload });
const t11_ok = t11_res === null && cacheStore['nonce_nonce-t11'] !== undefined && cacheStore['nonce_nonce-t11'].expiresAt === currentTime + 900;

// T12: Replay request yang sama setelah 361 detik -> REPLAYED_NONCE (fixes finding: timestamp still valid, nonce remains cached)
currentTime = 1000000 + 361;
const t12_res = appsScript.validateAuthentication({ timestamp: t11_ts, nonce: 'nonce-t11', signature: t11_sig, payload: testPayload });
const t12_ok = t12_res && t12_res.error_code === 'REPLAYED_NONCE';

// T13: Replay sebelum akhir freshness window (T+599s) -> REPLAYED_NONCE
currentTime = 1000000 + 599;
const t13_res = appsScript.validateAuthentication({ timestamp: t11_ts, nonce: 'nonce-t11', signature: t11_sig, payload: testPayload });
const t13_ok = t13_res && t13_res.error_code === 'REPLAYED_NONCE';

// T14: Request melewati akhir freshness window (+601s dari T=0, diff = 301s > 300s) -> EXPIRED_REQUEST
currentTime = 1000000 + 601;
const t14_res = appsScript.validateAuthentication({ timestamp: t11_ts, nonce: 'nonce-t11', signature: t11_sig, payload: testPayload });
const t14_ok = t14_res && t14_res.error_code === 'EXPIRED_REQUEST';

// T15: Request timestamp masa lalu pada batas -300 detik
currentTime = 1000000;
const t15_past_ts = currentTime - 300;
const t15_sig = signRequest(t15_past_ts, 'nonce-t15', testPayload, SECRET);
const t15_res = appsScript.validateAuthentication({ timestamp: t15_past_ts, nonce: 'nonce-t15', signature: t15_sig, payload: testPayload });
const t15_past_expired_ts = currentTime - 301;
const t15_expired_sig = signRequest(t15_past_expired_ts, 'nonce-t15-expired', testPayload, SECRET);
const t15_expired_res = appsScript.validateAuthentication({ timestamp: t15_past_expired_ts, nonce: 'nonce-t15-expired', signature: t15_expired_sig, payload: testPayload });
const t15_ok = t15_res === null && t15_expired_res.error_code === 'EXPIRED_REQUEST';

// T16: Request menggunakan nonce sama dengan payload berbeda -> Ditolak ketika nonce masih tercatat
currentTime = 1000000 + 200;
const tamperedPayload = { action: 'tampered', test: 123 };
const t16_sig = signRequest(currentTime, 'nonce-t15', tamperedPayload, SECRET);
const t16_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t15', signature: t16_sig, payload: tamperedPayload });
const t16_ok = t16_res && t16_res.error_code === 'REPLAYED_NONCE';

// T17: Request dengan invalid signature -> Tidak mengonsumsi nonce
currentTime = 1000000;
const t17_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t17', signature: 'tampered_sig_17', payload: testPayload });
const t17_ok = t17_res && t17_res.error_code === 'INVALID_SIGNATURE' && cacheStore['nonce_nonce-t17'] === undefined;

// T18: Lock acquisition gagal -> Tidak mengakses atau mencatat nonce
lockShouldSucceed = false; lockShouldThrow = false;
const t18_sig = signRequest(currentTime, 'nonce-t18', testPayload, SECRET);
const t18_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t18', signature: t18_sig, payload: testPayload });
const t18_ok = t18_res && t18_res.error_code === 'LOCK_TIMEOUT' && t18_res.is_retryable === true && cacheStore['nonce_nonce-t18'] === undefined;
lockShouldSucceed = true;

// T19: Cache error -> Fail-closed
global.CacheService = { getScriptCache: () => { throw new Error('Simulated cache crash'); } };
const t19_sig = signRequest(currentTime, 'nonce-t19', testPayload, SECRET);
const t19_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t19', signature: t19_sig, payload: testPayload });
const t19_ok = t19_res && t19_res.error_code === 'CACHE_SERVICE_UNAVAILABLE' && t19_res.is_retryable === true;
global.CacheService = origCache;

// T20: Request valid dengan nonce baru -> Berhasil setelah kondisi error pulih
const t20_sig = signRequest(currentTime, 'nonce-t20', testPayload, SECRET);
const t20_res = appsScript.validateAuthentication({ timestamp: currentTime, nonce: 'nonce-t20', signature: t20_sig, payload: testPayload });
const t20_ok = t20_res === null && cacheStore['nonce_nonce-t20'] !== undefined;

process.stdout.write(JSON.stringify({
  t01_ok, t02_ok, t03_ok, t04_ok, t05_ok, t06_ok, t07_ok, t08_ok, t09_ok, t10_ok,
  t11_ok, t12_ok, t13_ok, t14_ok, t15_ok, t16_ok, t17_ok, t18_ok, t19_ok, t20_ok
}));
JS;

        $process = new Process(['node']);
        $process->setInput($nodeScript);
        $process->mustRun();
        $output = json_decode(trim($process->getOutput()), true, 512, JSON_THROW_ON_ERROR);

        $this->assertTrue($output['t01_ok'], 'T01: Invalid signature must be rejected and must not mutate cache.');
        $this->assertTrue($output['t02_ok'], 'T02: Valid signature with acquired lock must authenticate and cache nonce.');
        $this->assertTrue($output['t03_ok'], 'T03: Sequential replay of valid request must be rejected with REPLAYED_NONCE.');
        $this->assertTrue($output['t04_ok'], 'T04: Lock timeout must fail-closed with retryable LOCK_TIMEOUT.');
        $this->assertTrue($output['t05_ok'], 'T05: Lock exception must fail-closed with retryable LOCK_TIMEOUT.');
        $this->assertTrue($output['t06_ok'], 'T06: Missing LockService must fail-closed with retryable LOCK_SERVICE_UNAVAILABLE.');
        $this->assertTrue($output['t07_ok'], 'T07: CacheService crash must release acquired lock and fail-closed.');
        $this->assertTrue($output['t08_ok'], 'T08: Failed lock attempt must not prevent subsequent valid request once lock is available.');
        $this->assertTrue($output['t09_ok'], 'T09: Concurrency contention must reject competing worker with LOCK_TIMEOUT and subsequent replay with REPLAYED_NONCE.');
        $this->assertTrue($output['t10_ok'], 'T10: PHP hash_hmac signature must interoperate with Apps Script validation.');
        $this->assertTrue($output['t11_ok'], 'T11: Future timestamp boundary (+300s) on initial request must be accepted.');
        $this->assertTrue($output['t12_ok'], 'T12: Replay after 361s within validity window must be rejected with REPLAYED_NONCE.');
        $this->assertTrue($output['t13_ok'], 'T13: Replay before end of freshness window must be rejected with REPLAYED_NONCE.');
        $this->assertTrue($output['t14_ok'], 'T14: Request past freshness window (+601s) must be rejected with EXPIRED_REQUEST.');
        $this->assertTrue($output['t15_ok'], 'T15: Past timestamp boundary (-300s accepted, -301s rejected) must enforce freshness contract.');
        $this->assertTrue($output['t16_ok'], 'T16: Request reusing existing nonce with different payload must be rejected with REPLAYED_NONCE.');
        $this->assertTrue($output['t17_ok'], 'T17: Request with invalid signature must not consume nonce in cache.');
        $this->assertTrue($output['t18_ok'], 'T18: Failed lock acquisition must not access or mutate cache.');
        $this->assertTrue($output['t19_ok'], 'T19: CacheService failure must fail-closed with CACHE_SERVICE_UNAVAILABLE.');
        $this->assertTrue($output['t20_ok'], 'T20: Valid request with new nonce must succeed after error recovery.');
    }

    /**
     * S17.18G.6-B Wave 2C-B: Comprehensive Queue, Worker Leasing, Retry & Idempotency Matrix (T01 - T20).
     */
    public function test_wave2cb_comprehensive_queue_worker_leasing_and_idempotency_matrix_t01_to_t20(): void
    {
        // -------------------------------------------------------------------------
        // SETUP: Base registration with verified prior sync & sidecar answers
        // -------------------------------------------------------------------------
        $reg = $this->createVerifiedAcceptedRegistration();
        $mainSync = $this->syncEngine->queueSyncForRegistration($reg);
        $this->assertNotNull($mainSync);
        $this->syncEngine->processSyncRecord($mainSync);
        $this->assertEquals(SpreadsheetRowSync::STATUS_SYNCED, $mainSync->fresh()->sync_status);

        $draft = $this->formBuilder->getOrCreateDraft(2026, $this->admin);
        $this->formBuilder->addFieldToDraft($draft, [
            'field_key'  => 't_matrix_github',
            'field_type' => 'url',
            'label'      => 'GitHub Profile',
        ]);
        $published = $this->formBuilder->publishVersion($draft, $this->admin);
        $this->formBuilder->freezeSnapshot($reg, $published);
        $this->formBuilder->saveCustomAnswers($reg, ['t_matrix_github' => 'https://github.com/matrix-t01-t20'], $published, $this->admin);

        // -------------------------------------------------------------------------
        // T01: Concurrent lease claims (1 winner, 1 rejected)
        // -------------------------------------------------------------------------
        $sidecarT01 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $this->assertNotNull($sidecarT01);
        $tokenWinner = 'worker-winner-' . uniqid();
        $tokenLoser = 'worker-loser-' . uniqid();

        // Winner claims lease via processSidecarSyncRecord with requestedFenceToken
        $claimedWinner = $this->syncEngine->processSidecarSyncRecord($sidecarT01, requestedFenceToken: $tokenWinner);
        $this->assertTrue($claimedWinner, 'T01: Winner must successfully claim lease and sync.');
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $sidecarT01->fresh()->sync_status);

        // Reset to pending for direct concurrent update test
        $sidecarT01->update(['sync_status' => SpreadsheetSidecarSync::STATUS_PENDING, 'locked_at' => null, 'locked_by' => null]);
        $claimedDirect1 = DB::table('spreadsheet_sidecar_syncs')
            ->where('id', $sidecarT01->id)
            ->where('sync_status', '!=', SpreadsheetSidecarSync::STATUS_PROCESSING)
            ->where(function ($q) {
                $q->whereNull('locked_at')->orWhere('locked_at', '<', now()->subSeconds(300));
            })
            ->update(['sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING, 'locked_at' => now(), 'locked_by' => $tokenWinner]);

        $claimedDirect2 = DB::table('spreadsheet_sidecar_syncs')
            ->where('id', $sidecarT01->id)
            ->where('sync_status', '!=', SpreadsheetSidecarSync::STATUS_PROCESSING)
            ->where(function ($q) {
                $q->whereNull('locked_at')->orWhere('locked_at', '<', now()->subSeconds(300));
            })
            ->update(['sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING, 'locked_at' => now(), 'locked_by' => $tokenLoser]);

        $this->assertEquals(1, $claimedDirect1, 'T01: First concurrent worker must acquire lease.');
        $this->assertEquals(0, $claimedDirect2, 'T01: Second concurrent worker must be rejected.');
        $this->assertEquals($tokenWinner, $sidecarT01->fresh()->locked_by);

        // -------------------------------------------------------------------------
        // T02: Stale worker loses lease and cannot overwrite new worker
        // -------------------------------------------------------------------------
        $tokenStale = 'worker-stale-' . uniqid();
        $tokenNew = 'worker-new-' . uniqid();
        $sidecarT01->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now(),
            'locked_by'   => $tokenNew,
        ]);

        $reflection = new \ReflectionClass($this->syncEngine);
        $updateSidecarMethod = $reflection->getMethod('updateSidecarGuardedByFence');
        $updateSidecarMethod->setAccessible(true);

        $staleUpdateResult = $updateSidecarMethod->invoke(
            $this->syncEngine,
            $sidecarT01,
            $tokenStale,
            ['sync_status' => SpreadsheetSidecarSync::STATUS_SYNCED, 'error_message' => 'stale overwrite attempt']
        );
        $this->assertFalse($staleUpdateResult, 'T02: Stale worker update must be rejected by fence mismatch.');
        $this->assertEquals($tokenNew, $sidecarT01->fresh()->locked_by);
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_PROCESSING, $sidecarT01->fresh()->sync_status);

        // -------------------------------------------------------------------------
        // T03: Delayed failed() callback from old worker (tested using serialized/unserialized job payload) cannot wipe new worker's lease
        // -------------------------------------------------------------------------
        // Sub-case 3A: ProcessSidecarSyncJob
        $sidecarT03 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $jobA = new ProcessSidecarSyncJob($sidecarT03->id);
        $serializedJobA = serialize($jobA);
        $tokenJobA = $jobA->fenceToken;

        // Simulate Worker A was processing, but its lease expired (> 300s)
        $sidecarT03->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now()->subMinutes(10),
            'locked_by'   => $tokenJobA,
        ]);

        // Worker B arrives, reclaims lease with fresh token
        $tokenJobB = 'worker-b-active-' . uniqid();
        $sidecarT03->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now(),
            'locked_by'   => $tokenJobB,
        ]);

        // Worker A's job finally fails in Laravel queue and triggers failed() on reconstructed instance
        /** @var ProcessSidecarSyncJob $reconstructedJobA */
        $reconstructedJobA = unserialize($serializedJobA);
        $this->assertEquals($tokenJobA, $reconstructedJobA->fenceToken, 'T03: Durable fence token must survive job deserialization.');

        $reconstructedJobA->failed(new \RuntimeException("Worker A timeout exception"));
        $freshSidecarT03 = $sidecarT03->fresh();
        $this->assertEquals($tokenJobB, $freshSidecarT03->locked_by, 'T03: Delayed failed() callback from Job A must NOT wipe Job B active lease.');
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_PROCESSING, $freshSidecarT03->sync_status);
        $this->assertNull($freshSidecarT03->error_message, 'T03: Job A error message must not overwrite Job B record.');

        // Sub-case 3B: ProcessSpreadsheetRowSyncJob
        $rowJobA = new \App\Jobs\ProcessSpreadsheetRowSyncJob($mainSync->id);
        $serializedRowJobA = serialize($rowJobA);
        $tokenRowJobA = $rowJobA->fenceToken;

        $mainSync->update([
            'sync_status' => SpreadsheetRowSync::STATUS_PROCESSING,
            'locked_at'   => now()->subMinutes(10),
            'locked_by'   => $tokenRowJobA,
        ]);

        $tokenRowJobB = 'worker-row-b-' . uniqid();
        $mainSync->update([
            'sync_status' => SpreadsheetRowSync::STATUS_PROCESSING,
            'locked_at'   => now(),
            'locked_by'   => $tokenRowJobB,
        ]);

        /** @var \App\Jobs\ProcessSpreadsheetRowSyncJob $reconstructedRowJobA */
        $reconstructedRowJobA = unserialize($serializedRowJobA);
        $this->assertEquals($tokenRowJobA, $reconstructedRowJobA->fenceToken, 'T03: Row job fence token must survive deserialization.');
        $reconstructedRowJobA->failed(new \RuntimeException("Worker A row sync crash"));

        $freshMainSync = $mainSync->fresh();
        $this->assertEquals($tokenRowJobB, $freshMainSync->locked_by, 'T03: Delayed row failed() callback must not steal active lease.');
        $this->assertEquals(SpreadsheetRowSync::STATUS_PROCESSING, $freshMainSync->sync_status);

        // Reset main sync to synced for subsequent tests
        $mainSync->update(['sync_status' => SpreadsheetRowSync::STATUS_SYNCED, 'locked_at' => null, 'locked_by' => null]);

        // -------------------------------------------------------------------------
        // T04: Worker crash and stale lease recovery (>300s)
        // -------------------------------------------------------------------------
        $sidecarT04 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT04->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now()->subSeconds(350),
            'locked_by'   => 'dead-crashed-worker-token',
        ]);

        $dispatchedCount = $this->syncEngine->scanAndDispatchPendingSidecarSyncs(limit: 10, dryRun: false);
        $this->assertGreaterThanOrEqual(1, $dispatchedCount, 'T04: Recovery scanner must detect expired lease for redispatch.');

        // Worker executes recovery
        $recovered = $this->syncEngine->processSidecarSyncRecord($sidecarT04);
        $this->assertTrue($recovered, 'T04: Stale lease must be reclaimed and processed to completion.');
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $sidecarT04->fresh()->sync_status);
        $this->assertNull($sidecarT04->fresh()->locked_by);

        // -------------------------------------------------------------------------
        // T05: Dual scanner duplicate queue dispatch handled safely
        // -------------------------------------------------------------------------
        $sidecarT05 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT05->update(['sync_status' => SpreadsheetSidecarSync::STATUS_PENDING, 'payload_checksum' => null, 'locked_at' => null, 'locked_by' => null]);

        $tokenWorker1 = 'scanner-job-1';
        $tokenWorker2 = 'scanner-job-2';

        $run1 = $this->syncEngine->processSidecarSyncRecord($sidecarT05, requestedFenceToken: $tokenWorker1);
        $this->assertTrue($run1, 'T05: First dispatched job must succeed.');
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $sidecarT05->fresh()->sync_status);

        // Second job arrives: record already SYNCED with identical checksum -> idempotent no-op returns true, makes 0 transport calls
        $mockCallsBefore = $this->mockTransport->callCount;
        $run2 = $this->syncEngine->processSidecarSyncRecord($sidecarT05, requestedFenceToken: $tokenWorker2);
        $this->assertTrue($run2, 'T05: Second dispatched job must be idempotent no-op.');
        $this->assertEquals($mockCallsBefore, $this->mockTransport->callCount, 'T05: Duplicate dispatch must not trigger remote transport.');

        // -------------------------------------------------------------------------
        // T06: Retry before next_retry_at held fail-closed (Scanner does not dispatch)
        // -------------------------------------------------------------------------
        $sidecarT06 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT06->update([
            'sync_status'   => SpreadsheetSidecarSync::STATUS_RETRYING,
            'next_retry_at' => now()->addMinutes(15),
            'locked_at'     => null,
            'locked_by'     => null,
            'attempt_count' => 1,
        ]);

        Queue::fake();
        $scannedPremature = $this->syncEngine->scanAndDispatchPendingSidecarSyncs();
        $this->assertEquals(0, $scannedPremature, 'T06: Premature retry before next_retry_at must not be dispatched by scanner (fail-closed).');
        Queue::assertNothingPushed();

        // Same verification on SpreadsheetRowSync scanner
        $mainSync->update([
            'sync_status'   => SpreadsheetRowSync::STATUS_RETRYING,
            'next_retry_at' => now()->addMinutes(15),
            'locked_at'     => null,
            'locked_by'     => null,
        ]);
        $rowScannedPremature = $this->syncEngine->scanAndDispatchPendingSyncs();
        $this->assertEquals(0, $rowScannedPremature, 'T06: Main row premature retry before next_retry_at must not be dispatched.');
        $mainSync->update(['sync_status' => SpreadsheetRowSync::STATUS_SYNCED, 'next_retry_at' => null]);

        // -------------------------------------------------------------------------
        // T07: Retry after next_retry_at processed (Scanner dispatches matured retry)
        // -------------------------------------------------------------------------
        $sidecarT06->update([
            'sync_status'   => SpreadsheetSidecarSync::STATUS_RETRYING,
            'next_retry_at' => now()->subSeconds(30),
            'payload_checksum' => null,
            'locked_at'     => null,
            'locked_by'     => null,
        ]);
        $scannedMatured = $this->syncEngine->scanAndDispatchPendingSidecarSyncs();
        $this->assertGreaterThanOrEqual(1, $scannedMatured, 'T07: Matured retry after next_retry_at must be dispatched by scanner.');
        $maturedResult = $this->syncEngine->processSidecarSyncRecord($sidecarT06, force: false);
        $this->assertTrue($maturedResult, 'T07: Matured retry after next_retry_at must be processed.');
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $sidecarT06->fresh()->sync_status);

        // -------------------------------------------------------------------------
        // T08: Exponential backoff schedule and max attempts
        // -------------------------------------------------------------------------
        $this->assertSame(30, SpreadsheetSidecarSync::calculateBackoffSeconds(1));
        $this->assertSame(120, SpreadsheetSidecarSync::calculateBackoffSeconds(2));
        $this->assertSame(600, SpreadsheetSidecarSync::calculateBackoffSeconds(3));
        $this->assertSame(1800, SpreadsheetSidecarSync::calculateBackoffSeconds(4));
        $this->assertSame(3600, SpreadsheetSidecarSync::calculateBackoffSeconds(5));

        $this->assertSame(60, SpreadsheetRowSync::calculateBackoffSeconds(1));
        $this->assertSame(300, SpreadsheetRowSync::calculateBackoffSeconds(2));
        $this->assertSame(900, SpreadsheetRowSync::calculateBackoffSeconds(3));
        $this->assertSame(3600, SpreadsheetRowSync::calculateBackoffSeconds(4));
        $this->assertSame(14400, SpreadsheetRowSync::calculateBackoffSeconds(5));

        // When attempt_count hits max_attempts (5), next failure transitions to STATUS_FAILED
        $sidecarT08 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT08->update([
            'sync_status'   => SpreadsheetSidecarSync::STATUS_PENDING,
            'attempt_count' => 4,
            'max_attempts'  => 5,
            'locked_at'     => null,
            'locked_by'     => null,
        ]);
        $this->mockTransport->forcedResponse = SpreadsheetTransportResponse::failure(
            errorMessage: 'Simulated 5th failure',
            errorCode: 'TRANSPORT_ERROR',
            isRetryable: true
        );
        $this->syncEngine->processSidecarSyncRecord($sidecarT08, force: true);
        $this->mockTransport->forcedResponse = null;
        $freshT08 = $sidecarT08->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_FAILED, $freshT08->sync_status, 'T08: Exhausted attempts must transition to FAILED.');
        $this->assertEquals(5, $freshT08->attempt_count);
        $this->assertNull($freshT08->next_retry_at);

        // -------------------------------------------------------------------------
        // T09: Terminal errors halt without automatic retry
        // -------------------------------------------------------------------------
        $sidecarT09 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT09->update(['sync_status' => SpreadsheetSidecarSync::STATUS_PENDING, 'attempt_count' => 0, 'locked_at' => null, 'locked_by' => null]);
        $this->mockTransport->forcedResponse = SpreadsheetTransportResponse::failure(
            errorMessage: 'HMAC signature verification rejected',
            errorCode: 'AUTH_FAILED',
            isRetryable: false
        );
        $resT09 = $this->syncEngine->processSidecarSyncRecord($sidecarT09, force: true);
        $this->mockTransport->forcedResponse = null;
        $this->assertFalse($resT09);
        $freshT09 = $sidecarT09->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_FAILED, $freshT09->sync_status, 'T09: Terminal AUTH_FAILED must halt without retry.');
        $this->assertNull($freshT09->next_retry_at);

        // -------------------------------------------------------------------------
        // T10: Transient errors transition to retrying with backoff
        // -------------------------------------------------------------------------
        $sidecarT10 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT10->update(['sync_status' => SpreadsheetSidecarSync::STATUS_PENDING, 'attempt_count' => 0, 'locked_at' => null, 'locked_by' => null]);
        $this->mockTransport->forcedResponse = SpreadsheetTransportResponse::failure(
            errorMessage: 'Google Apps Script read timeout',
            errorCode: 'TRANSPORT_TIMEOUT',
            isRetryable: true
        );
        $resT10 = $this->syncEngine->processSidecarSyncRecord($sidecarT10, force: true);
        $this->mockTransport->forcedResponse = null;
        $this->assertFalse($resT10);
        $freshT10 = $sidecarT10->fresh();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_RETRYING, $freshT10->sync_status, 'T10: Transient error must transition to RETRYING.');
        $this->assertEquals(1, $freshT10->attempt_count);
        $this->assertNotNull($freshT10->next_retry_at);
        $this->assertNull($freshT10->locked_by);

        // -------------------------------------------------------------------------
        // T11: Remote success with HTTP timeout retries idempotently
        // -------------------------------------------------------------------------
        $sidecarT11 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $syncIdT11 = $sidecarT11->external_sync_id;
        // Pre-populate remote row as if remote Apps Script executed successfully before timeout
        $this->mockTransport->remoteSheets['2026_Custom_Fields'][$syncIdT11] = [
            'SERTIF_SYNC_ID'         => $syncIdT11,
            'SERTIF_REGISTRATION_ID' => (string) $reg->id,
            'FORM_SCHEMA_VERSION'    => '',
            'SERTIF_LAST_SYNC_AT'    => now()->toIso8601String(),
            't_matrix_github'        => 'https://github.com/matrix-t01-t20',
        ];
        $countBeforeT11 = $this->mockTransport->getRemoteRowCount('2026_Custom_Fields');

        // Retry should match existing remote row by SERTIF_SYNC_ID without inserting new row
        $resT11 = $this->syncEngine->processSidecarSyncRecord($sidecarT11, force: true);
        $this->assertTrue($resT11, 'T11: Retry after remote success must succeed.');
        $this->assertEquals($countBeforeT11, $this->mockTransport->getRemoteRowCount('2026_Custom_Fields'), 'T11: Zero duplicate remote rows on retry.');

        // -------------------------------------------------------------------------
        // T12: Worker crash after remote success recovers cleanly without duplicates
        // -------------------------------------------------------------------------
        $sidecarT12 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT12->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now()->subMinutes(10),
            'locked_by'   => 'crashed-after-remote-write',
        ]);
        $countBeforeT12 = $this->mockTransport->getRemoteRowCount('2026_Custom_Fields');
        $resT12 = $this->syncEngine->processSidecarSyncRecord($sidecarT12);
        $this->assertTrue($resT12, 'T12: Worker crash recovery must succeed.');
        $this->assertEquals($countBeforeT12, $this->mockTransport->getRemoteRowCount('2026_Custom_Fields'), 'T12: Zero duplicate rows on crash recovery.');
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_SYNCED, $sidecarT12->fresh()->sync_status);

        // -------------------------------------------------------------------------
        // T13: Identical payload retry produces zero duplicate remote rows
        // -------------------------------------------------------------------------
        $rowsBeforeT13 = $this->mockTransport->getRemoteRowCount('2026_Custom_Fields');
        $resT13 = $this->syncEngine->processSidecarSyncRecord($sidecarT12);
        $this->assertTrue($resT13, 'T13: Identical payload retry must be idempotent.');
        $this->assertEquals($rowsBeforeT13, $this->mockTransport->getRemoteRowCount('2026_Custom_Fields'), 'T13: Zero new rows created.');

        // -------------------------------------------------------------------------
        // T14: Payload changes update existing row accurately
        // -------------------------------------------------------------------------
        $this->formBuilder->saveCustomAnswers($reg, ['t_matrix_github' => 'https://github.com/matrix-UPDATED'], $published, $this->admin);
        $sidecarT14 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $resT14 = $this->syncEngine->processSidecarSyncRecord($sidecarT14, force: true);
        $this->assertTrue($resT14, 'T14: Payload update must succeed.');
        $remoteRowT14 = $this->mockTransport->getRemoteRow('2026_Custom_Fields', $sidecarT14->external_sync_id);
        $this->assertEquals('https://github.com/matrix-UPDATED', $remoteRowT14['t_matrix_github'], 'T14: Remote row must reflect updated payload.');

        // -------------------------------------------------------------------------
        // T15: Fencing token prevents stale database updates
        // -------------------------------------------------------------------------
        $sidecarT15 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT15->update(['sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING, 'locked_at' => now(), 'locked_by' => 'active-token-15']);
        $staleWrite = $updateSidecarMethod->invoke(
            $this->syncEngine,
            $sidecarT15,
            'stale-token-15',
            ['sync_status' => SpreadsheetSidecarSync::STATUS_SYNCED]
        );
        $this->assertFalse($staleWrite, 'T15: Update with wrong fencing token must fail-closed.');
        $this->assertEquals('active-token-15', $sidecarT15->fresh()->locked_by);

        // -------------------------------------------------------------------------
        // T16: Main row prerequisite unfulfilled halts sidecar (fail-closed)
        // -------------------------------------------------------------------------
        $regUnsynced = $this->createVerifiedAcceptedRegistration();
        $this->formBuilder->freezeSnapshot($regUnsynced, $published);
        $this->formBuilder->saveCustomAnswers($regUnsynced, ['t_matrix_github' => 'https://github.com/unsynced-reg'], $published, $this->admin);

        $sidecarT16 = $this->syncEngine->queueSidecarSyncForRegistration($regUnsynced);
        $callsBeforeT16 = $this->mockTransport->callCount;
        $resT16 = $this->syncEngine->processSidecarSyncRecord($sidecarT16);
        $this->assertFalse($resT16, 'T16: Unsynced main row must halt sidecar sync fail-closed.');
        $this->assertEquals($callsBeforeT16, $this->mockTransport->callCount, 'T16: Zero remote transport calls when main row unsynced.');
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_RETRYING, $sidecarT16->fresh()->sync_status);
        $this->assertStringContainsString('MAIN_ROW_NOT_SYNCED', $sidecarT16->fresh()->error_message);

        // -------------------------------------------------------------------------
        // T17: Manual retry while worker is active is rejected safely
        // -------------------------------------------------------------------------
        $sidecarT17 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT17->update([
            'sync_status' => SpreadsheetSidecarSync::STATUS_PROCESSING,
            'locked_at'   => now(),
            'locked_by'   => 'active-running-worker',
        ]);
        $reconcileBlocked = $this->syncEngine->reconcileSidecarForRegistration($reg, $this->admin);
        $this->assertNull($reconcileBlocked, 'T17: Manual reconcile must be rejected while worker holds active lease.');
        $this->assertEquals('active-running-worker', $sidecarT17->fresh()->locked_by);

        // -------------------------------------------------------------------------
        // T18: Recovery dry-run performs zero mutations or job dispatches
        // -------------------------------------------------------------------------
        $sidecarT18 = $this->syncEngine->queueSidecarSyncForRegistration($reg);
        $sidecarT18->update([
            'sync_status'   => SpreadsheetSidecarSync::STATUS_PENDING,
            'next_retry_at' => now()->subMinutes(5),
            'locked_at'     => null,
            'locked_by'     => null,
        ]);
        Queue::fake();
        $dryRunCount = $this->syncEngine->scanAndDispatchPendingSidecarSyncs(limit: 50, dryRun: true);
        $this->assertGreaterThanOrEqual(1, $dryRunCount, 'T18: Dry run must report eligible count.');
        Queue::assertNothingPushed();
        $this->assertEquals(SpreadsheetSidecarSync::STATUS_PENDING, $sidecarT18->fresh()->sync_status);

        // -------------------------------------------------------------------------
        // T19: Zero unauthorized mutations on registrations/snapshots/custom answers
        // -------------------------------------------------------------------------
        $regCheck = $reg->fresh();
        $this->assertEquals(InternshipRegistration::STATUS_ACCEPTED, $regCheck->internship_status, 'T19: Registration status must remain intact.');
        $this->assertEquals($published->version_code, $regCheck->formSnapshot->form_schema_version, 'T19: Snapshot version must remain intact.');
        $answersMap = RegistrationCustomAnswer::where('registration_id', $reg->id)->pluck('answer_value', 'field_key')->toArray();
        $this->assertArrayHasKey('t_matrix_github', $answersMap);
        $this->assertEquals('https://github.com/matrix-UPDATED', $answersMap['t_matrix_github'], 'T19: Custom answers must remain intact.');

        // -------------------------------------------------------------------------
        // T20: Regression of Wave 2C-A HMAC, nonce, and transport contract
        // -------------------------------------------------------------------------
        $this->test_r04_full_lock_safety_nonce_replay_and_time_window_matrix_t01_to_t20();
    }
}


